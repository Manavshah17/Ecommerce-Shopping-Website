<?php
$servername="localhost";
$username="root";
$password="";
$database="cart";
$con=mysqli_connect($servername,$username,$password,$database);

if(!$con){
    die("Sorry we failed to connect :".mysqli_connect_error());
}
else{
    echo "Connection was successful";
}

$sql="CREATE DATABASE IF NOT EXISTS $database";


if(mysqli_query($con,$sql)){
    $con=mysqli_connect($servername,$username,$password,$database)

    $sql="CREATE TABLE IF NOT EXISTS "


}






?>