<?php
$insert=false;
if(isset($_POST['name'])){
    $server="localhost";
    $username="root";
    $password="";

    $con=mysqli_connect($server,$username,$password);

    if(!$con){
        die("connection to this database failed due to".mysqli_connect_error());
    }
    // echo "Success Connecting to the Database";

    // COLLECT ALL POST VARIABLES
    $name=$_POST['name'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];
    $sql= "INSERT INTO `contactus`.`ecommerce_contact` (`name`, `email`, `subject`, `message`) VALUES ('$name',' $email','$subject','$message');";
    // echo $sql;
    
    if($con->query($sql)==true){
        echo "Your Forrm is Submitted Successfully";
        // echo "Successfully insert";
    }
    else{
        // echo "ERROR <br> $con->error";
    }
    $con->close();
}
?>

