<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Julee&display=swap" rel="stylesheet">
<script src="contact.js"></script>
</head>
<body>
    <section id="header">
        <a href="index.php"><img src="img/sportsloungelogo.png" alt="logo" class="logo"></a>
    <div>
        <ul id="navbar">
            <li><a href="index.php" >Home</a></li>
            <li><a href="shop.php" >Shop</a></li>
            <li><a href="blog.php" >Blog</a></li>
            <li><a href="about.php" >About</a></li>
            <li><a href="contact2.php" class="active">Contact</a></li>
            <button class="signup_btn"><a href="/loginsystem/signup.php" style="text-decoration: none; color: black;">Login / Signup</a> </button>
            <?php 
            session_start();
            echo $_SESSION['username'];
            ?>
            <?php
                $count=0;
                if(isset($_SESSION['cart'])){
                    $count=count($_SESSION['cart']);
                }
            ?>
            <li><a href="cart.php" id="lg-bag"><i class="fa-solid fa-bag-shopping" ></i><?php echo '  ('.$count.')   '?></a></li>
            <a href="#" id="close"><i class="fa fa-window-close" aria-hidden="true"></i></a>
        </ul>
    </div>
    <div id="mobile">
        <a href="cart.html"><i class="fa-solid fa-bag-shopping"></i></a>
        <i id="bar" class="fas fa-outdent"></i>
    </div>
    </section>
    <section id="page-header" class="about-header">
        
        <h2>#Let's Talk</h2>
        <p>Contact Us</p>
        
       
       
    </section>
    
    <section id="contact-details" class="section-p1">
        <div class="details">
            <span>GET IN TOUCH</span>
            <h2>Write to one of our Agency</h2>
            <h3>Head Office</h3>
            <div>
                <li>
                    <i class="fa fa-map-marker"></i>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, sapiente.</p>
                </li>
                <li>
                    <i class="far fa-envelope"></i>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, sapiente.</p>
                </li>
                <li>
                    <i class="fas fa-phone-alt"></i>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, sapiente.</p>
                </li>
                <li>
                    <i class="far fa-clock"></i>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur, sapiente.</p>
                </li>
            </div>
        </div>
        <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3770.0991975294487!2d72.83441011461393!3d19.10330368707226!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c9b8676487ef%3A0x2c4fac1c801d5128!2sNMIMS%20Deemed-to-be-University!5e0!3m2!1sen!2sin!4v1678009308849!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </section>

    <section id="form-details">
        <form name="Contact" action="contact.php" method="post" onsubmit="return validateForm()">
            <span>Leave A Message</span>
            <h2>We would Love to hear From You</h2>
            <input type="text" placeholder="Your Name" name="name">
            <input type="email" placeholder="E-Mail" name="email">
            <input type="text" placeholder="Subject" name="subject">
            <textarea name="message" id="" cols="30" rows="10" placeholder="Your Message"></textarea>
            <br>
            <button>Submit</button>
            <br>
        </form>
        <div class="people">
            <div>
                <img src="img/people/fotor_2023-3-30_21_57_49.png" alt="">
                <p>
                    <span>Aryan</span><br>Chief Technology Officer<br>Phone:+91 3242334432 <br> Email:abc@gmail.com </p>
            </div>
            <div>
                <img src="img/people/mav.png" alt="">
                <p>
                    <span>Manav</span><br> Chief Executive Officer<br>Phone:+91 3242334432 <br> Email:abc@gmail.com
                </p>
            </div>
            <div>
                <img src="img/people/aman.jpg" alt="">
                <p>
                    <span>Aman</span><br>Cheif Marketing Manager <br>Phone:+91 3242334432 <br> Email:abc@gmail.com </p>
            </div>
        </div>
    </section>

    <section id="newsletter">
    <div class="newstext section-p1">
        
        <h4>Signup For Newsletters</h4>
        <p>Get Latest updates in your of our <span>Special offers</span> in  your inbox </p>
    </div>
    <div class="form section-p1">
        <input type="email" name="" id="" placeholder="Your Email Address">
        <button class="white">Signup</button>
    </div>
    </section>
    
    <footer class="section-p1">
        <div class="col">
            <img  class = "logo" src="img/sportsloungelogo_footer.png" alt="">
            <h4>Contact</h4>
            <p><strong>Address:</strong> Nmims Injhbffbfbfb udcsu stdevewe we cqcw itute</p>
            <p><strong>Hours:</strong> 08:00 to 20:00</p>
            <div class="follow">
                <h4>Follow Us</h4>
                <i class="fab fa-facebook-f"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-pinterest"></i>
                <i class="fab fa-youtube"></i>
            </div>
        </div>
        <div class="col">
                <h4>About</h4>
                <a href="#">About Us</a>
                <a href="#">Delivery Information</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms and Condiyions</a>
                <a href="#">Conatact Us</a>
        </div>
        <div class="col">
            <h4>My Account</h4>
            <a href="#">Sign-In</a>
            <a href="#">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help</a>
        </div>
        <div class="col install">
            <h4>Install App</h4>
            <p>From Google Play Store or App Store</p>
            <div class="row">
                <img src="img/pay/app.jpg" alt="">
                <img src="img/pay/play.jpg" alt="">
            </div>
            <p>Secure Payments Gateway</p>
            <img src="img/pay/pay.png" alt="">
        </div>
    </footer>
    <div class="copyright">
        <p>&copy 2023 SportsLounge-All Rights Reserved</p>
        </div>
    
   
</body>
</html>