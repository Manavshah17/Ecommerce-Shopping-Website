<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Julee&display=swap" rel="stylesheet">
<link rel="stylesheet" href="index.css">
</head>
<style>
   #product1 .pro-container{
    display: flex;
    justify-content: space-between;
    padding-top: 20px;
    flex-wrap: wrap;
}
div .addcart{
    font-size: 16px;
    font-weight: 600;
    padding: 11px 18px;
    color:white;
    background-color: #088178;
    cursor: pointer;
    border-radius:10px;
    border: 1px solid white;
    transition: 0.2s;
    outline: none;
    width: 280px;
    /* margin: 0; */
   
}
#product1 .pro .des{
    text-align: start;
    
    padding: 10px 0; 
}
#product1 .pro .des span{
    color: #606063;
    font-size: 12px;
    text-align: left;
}
</style>
<body>
<section id="header">
        <a href="index.php"><img src="img/sportsloungelogo.png" alt="logo" class="logo"></a>
    <div>
        <ul id="navbar">
            <li><a href="index.php" >Home</a></li>
            <li><a href="shop.php" class="active">Shop</a></li>
            <li><a href="blog.php" >Blog</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="contact2.php">Contact</a></li>
            <button class="signup_btn"><a href="/loginsystem/signup.php" style="text-decoration: none; color: black;">Login / Signup</a> </button>
            <?php 
            session_start();
            echo $_SESSION['username'];
            ?>
            <?php
                $count=0;
                if(isset($_SESSION['cart'])){
                    $count=count($_SESSION['cart']);
                }
            ?>
            <li><a href="cart.php" id="lg-bag"><i class="fa-solid fa-bag-shopping" ></i><?php echo '  ('.$count.')   '?></a></li>
            <a href="#" id="close"><i class="fa fa-window-close" aria-hidden="true"></i></a>
        </ul>
    </div>
    <div id="mobile">
        <a href="cart.html"><i class="fa-solid fa-bag-shopping"></i></a>
        <i id="bar" class="fas fa-outdent"></i>
    </div>
    </section>
    <section id="page-header">

        <h2>#SHOP NOW</h2>
        <p>Save More with coupons and get upto 70% OFF</p>
        
       
       
    </section>

    
    <secton id="product1" class="section-p1">
    <div  id="product1"class="section-p1"> 
            <h2>CATEGORIES</h2>
            <div>
                <li><a href="sproduct.php" style="text-decoration: none; color:black">Jersey</a></li>
                <li><a href="sproduct1.php" style="text-decoration: none; color:black">Supplement</a></li>

            </div>
        </div>
    <secton id="product1" class="section-p1">
        <h2>Sports Jerseys</h2>
        <p>Summer Collection New Modern Design</p>
        
        

        <div class="pro-container section-p1">
            
            <div class="pro">
            <form action="managecart.php" method="post" class="addcartform">
                <img src="img/Jersey/arsenal.png" alt="Arsenal">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Arsenal Home Jersey </h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹1999</h4>
                    <br>
                    <div>
                    <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                    <input type="hidden" name="Item_Name" value="Arsenal Home Jersey">
                    <input type="hidden" name="Price" value="1999">
                    </div>
                </div>
                </form>
            </div>
        
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/Jersey/juventus.png" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Juventus Home Jersey</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                     <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                     <input type="hidden" name="Item_Name" value="Juventus Home Jersey">
                    <input type="hidden" name="Price" value="999">
                    </div>
                </div>
                </form>
                </div>

            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/Jersey/interaway.jpg" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Inter Milan Away Jersey</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Inter Milan Away Jersey">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
            </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/Jersey/madridaway.png" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Real Madrid Away Jersey</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Real Madrid Away Jersey">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
                </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/Jersey/man_u.png" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Manchester United Home Jersey</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Manchester United Home Jersey">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
                </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/Jersey/madridhome.png" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Real Madrid Home Jersey</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Real Madrid Home Jersey">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
                </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/Jersey/spurs.png" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Spurs Home Jersey</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Spurs Home Jersey">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
            </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/Jersey/mancity.png" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Mancity Home Jersey</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                     <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Mancity Home Jersey">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
            </form>
            </div>
        </div>
    </secton>
    <secton id="product1" class="section-p1">
        <h2>Supplements</h2>
        <p>Summer Collection New Modern Design</p>
        <div class="pro-container section-p1">
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/supp/mb1.jpg" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>MuscleBlaze Supplement 1</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="MuscleBlaze Supplement 1">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
            </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/supp/creatine 4.jpg" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Creatine Supplement 4</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Creatine Supplement 4">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
            </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/supp/creatine12.jpg" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Creatine Supplement 12</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Creatine Supplement 12">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
            </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/supp/creatine2.jpg" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Creatine Supplement 2</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Creatine Supplement 2">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
            </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/supp/whey1.jpg" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Whey Protein 1</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Whey Protein 1">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
            </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/supp/whey2.jpg" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Whey Protein 2</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Whey Protein 2">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
            </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/supp/creatine3.jpg" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Creatine Supplement 3</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Creatine Supplement 3">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
            </form>
            </div>
            <div class="pro">
                <form action="managecart.php" method="post" class="addcartform">
                <img src="img/supp/creatine5.jpg" alt="">
                <div class="des">
                    <span>Adidas</span>
                    <h5>Creatine Supplement 5</h5>
                    <div class="star">
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                        <i class="fa-solid fa-star"></i>
                    </div>
                    <h4>₹999</h4>
                    <br>
                    <div>
                        <button class="addcart" type="submit"  name="Add_Cart">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="Creatine Supplement 5">
                        <input type="hidden" name="Price" value="999">
                    </div>
                </div>
            </form>
            </div>
        </div>
    </secton>
    <!-- <section id="pagination" class="section-p1">
        <a href="shop.html">1</a>
        <a href="#">2</a>
        <a href="#"><i class="fa-solid fa-arrow-right"></i></a>
    </section> -->
    
    
    <section id="newsletter">
        <div class="newstext section-p1">
            
            <h4>Signup For Newsletters</h4>
            <p>Get Latest updates in your of our <span>Special offers</span> in  your inbox </p>
        </div>
        <div class="form section-p1">
            <input type="email" name="" id="" placeholder="Your Email Address">
            <button class="white">Signup</button>
        </div>
    </section>
    <footer class="section-p1">
        <div class="col">
            <img  class = "logo" src="img/sportsloungelogo_footer.png" alt="">
            <h4>Contact</h4>
            <p><strong>Address:</strong> Nmims Injhbffbfbfb udcsu stdevewe we cqcw itute</p>
            <p><strong>Hours:</strong> 08:00 to 20:00</p>
            <div class="follow">
                <h4>Follow Us</h4>
                <i class="fab fa-facebook-f"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-pinterest"></i>
                <i class="fab fa-youtube"></i>
            </div>
        </div>
        <div class="col">
                <h4>About</h4>
                <a href="#">About Us</a>
                <a href="#">Delivery Information</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms and Condiyions</a>
                <a href="#">Conatact Us</a>
        </div>
        <div class="col">
            <h4>My Account</h4>
            <a href="#">Sign-In</a>
            <a href="#">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help</a>
        </div>
        <div class="col install">
            <h4>Install App</h4>
            <p>From Google Play Store or App Store</p>
            <div class="row">
                <img src="img/pay/app.jpg" alt="">
                <img src="img/pay/play.jpg" alt="">
            </div>
            <p>Secure Payments Gateway</p>
            <img src="img/pay/pay.png" alt="">
        </div>
    </footer>
    <div class="copyright">
        <p>&copy 2023 SportsLounge-All Rights Reserved</p>
        </div>
    <script src="script.js"></script>
    <script>
        $(document).ready(function(){
            alert("hi");
        })
    </script>
</body>
</html>