<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Julee&display=swap" rel="stylesheet">
</head>
<body>
    <section id="header">
        <a href="index.php"><img src="img/sportsloungelogo.png" alt="logo" class="logo"></a>
    <div>
        <ul id="navbar">
            <li><a href="index.php" >Home</a></li>
            <li><a href="shop.php" >Shop</a></li>
            <li><a href="blog.php" >Blog</a></li>
            <li><a href="about.php" class="active">About</a></li>
            <li><a href="contact2.php">Contact</a></li>
            <button class="signup_btn"><a href="signup_login.html" style="text-decoration: none; color: black;">Login / Signup</a> </button>
            <?php 
            session_start();
            echo $_SESSION['username'];
            ?>
            <?php
                $count=0;
                if(isset($_SESSION['cart'])){
                    $count=count($_SESSION['cart']);
                }
            ?>
            <li><a href="cart.php" id="lg-bag"><i class="fa-solid fa-bag-shopping" ></i><?php echo '  ('.$count.')   '?></a></li>
            <a href="#" id="close"><i class="fa fa-window-close" aria-hidden="true"></i></a>
        </ul>
    </div>
    <div id="mobile">
        <a href="cart.html"><i class="fa-solid fa-bag-shopping"></i></a>
        <i id="bar" class="fas fa-outdent"></i>
    </div>
    </section>
    <section id="page-header" class="about-header">
        
        <h2>#ABOUT US</h2>
        <p>Read all about us</p>
        
       
       
    </section>

   <section id="about-head" class="section-p1">
    <img src="img/about/a6.jpg" alt="">
    <div>
        <h2>Who are We ?</h2>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quidem illo modi, atque nam dolores earum blanditiis dolore quibusdam magni excepturi, deleniti officia eligendi accusantium sed voluptate nobis ullam praesentium amet sit. Sit alias cumque, v Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sequi laboriosam dicta culpa, tempora delectus nisi. lero amet mollitia delectus nemo quae esse nulla? Obcaecati explicabo eum reprehenderit atque in soluta cum veniam rerum rem. Deleniti, sed. Animi tempore eveniet magnam?</p>

        <abbr title="">Lorem ipsum dolor sit cdwdwc vwdw cqwlaceat unde.</abbr>
        <br><br>

        <marquee background-color="#ccc" loop="-1" scrollamount="5" >Lorem, ipsum dolor sit amet consectetur adipisicing elit. Est aliquid amet 
        </marquee>
    </div>
   </section>

   <section id="about-app" class="section-p1">
    <h1>Download Our <a href="">App</a></h1>
    <div class="video">
        <video  autoplay muted loop src="img/about/1.mp4"></video>
    </div>
   </section>
   <section id="feature" class="section-p1">
    <div class="feature-box ">
        <img src="img/features/f1.png" alt="Free Shipping" >
        <h6>Free Shipping</h6>
    </div>
    <div class="feature-box">
        <img src="img/features/f2.png" alt="Online Order" >
        <h6>Online Order</h6>
            </div>
    <div class="feature-box">
        <img src="img/features/f3.png" alt="Save Money" >
        <h6>Save Money</h6>
    </div>
    <div class="feature-box">
        <img src="img/features/f4.png" alt="Promotions">
        <h6>Promotions</h6>
    </div>
    <div class="feature-box">
        <img src="img/features/f5.png" alt="Happy Sell" >
        <h6>Happy Sales</h6> 
   </div>
    <div class="feature-box">
        <img src="img/features/f6.png" alt="24 X 7 Support">
        <h6>24X7 Support</h6> 
   </div>
</section>
    
<section id="newsletter">
    <div class="newstext section-p1">
        
        <h4>Signup For Newsletters</h4>
        <p>Get Latest updates in your of our <span>Special offers</span> in  your inbox </p>
    </div>
    <div class="form section-p1">
        <input type="email" name="" id="" placeholder="Your Email Address">
        <button class="white">Signup</button>
    </div>
</section>
    
    
    
    <footer class="section-p1">
        <div class="col">
            <img  class = "logo" src="img/sportsloungelogo_footer.png" alt="">
            <h4>Contact</h4>
            <p><strong>Address:</strong> Nmims Injhbffbfbfb udcsu stdevewe we cqcw itute</p>
            <p><strong>Hours:</strong> 08:00 to 20:00</p>
            <div class="follow">
                <h4>Follow Us</h4>
                <i class="fab fa-facebook-f"></i>
                <i class="fab fa-instagram"></i>
                <i class="fab fa-twitter"></i>
                <i class="fab fa-pinterest"></i>
                <i class="fab fa-youtube"></i>
            </div>
        </div>
        <div class="col">
                <h4>About</h4>
                <a href="#">About Us</a>
                <a href="#">Delivery Information</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms and Condiyions</a>
                <a href="#">Conatact Us</a>
        </div>
        <div class="col">
            <h4>My Account</h4>
            <a href="#">Sign-In</a>
            <a href="#">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="#">Help</a>
        </div>
        <div class="col install">
            <h4>Install App</h4>
            <p>From Google Play Store or App Store</p>
            <div class="row">
                <img src="img/pay/app.jpg" alt="">
                <img src="img/pay/play.jpg" alt="">
            </div>
            <p>Secure Payments Gateway</p>
            <img src="img/pay/pay.png" alt="">
        </div>
    </footer>
    <div class="copyright">
        <p>&copy 2023 SportsLounge-All Rights Reserved</p>
        </div>
    <script src="script.js"></script>
</body>
</html>