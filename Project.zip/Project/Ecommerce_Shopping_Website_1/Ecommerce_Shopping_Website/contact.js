function validateForm() {
    let x = document.forms["Contact"]["name"].value;
    let y = document.forms["Contact"]["email"].value;
    let z = document.forms["Contact"]["subject"].value;
    let a = document.forms["Contact"]["meaasge"].value;
    if (x == " " || y== " " || z== " " || a==" ")  {
      alert("Pls fill out all the details");
      return false;
    }
    
}