<?php
$servername="localhost";
$username="root";
$password="";
$database="users";
$con=mysqli_connect($servername,$username,$password,$database);
// echo "Hi";

if(!$con){
    // echo "Successfully Connected";
// }
// else{
    die("Error: ".mysqli_connect_error()); 
}


?>