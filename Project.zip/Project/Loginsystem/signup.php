<?php
$showalert=false;
$showerror=false;
if($_SERVER['REQUEST_METHOD']=="POST"){
    include 'partials/_dbconnect.php';
$username=$_POST['username'];
$password=$_POST['password'];
$confirmpassword=$_POST['confirmpassword'];

$exists=false;
$existsSql="SELECT * FROM `users` WHERE username='$username'";
$result=mysqli_query($con,$existsSql);
$numExistRows=mysqli_num_rows($result);
if($numExistRows>0){
    $exists=true;
    $showerror="Username already exists";
}

else{
  $exists=false;
  if($password==$confirmpassword){
      $sql="INSERT INTO `users`(`username`,`password`,`dt`) VALUES ('$username','$password',current_timestamp())";
      $result=mysqli_query($con,$sql);
      if($result){
          $showalert=true;
      }
  }
  else{
      $showerror="Passwords do not match";
  }
  }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  </head>
  <body>
    <?php require 'partials/_nav.php'; ?>
    <?php
    
    if($showalert){
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Success!!</strong> Your account is now created and you can login
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
      </div>';
    }
    if($showerror){
      echo' <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>ERROR!!</strong> '.$showerror.'
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
      </div>';
        
        }
        
    ?>
        <h1 class="text-center">Signup To SportsLounge</h1>
    
    <form action="/loginsystem/signup.php" method="post">
  <div class="form-group my-3">
    <label for="exampleInputEmail1">Username</label>
    <input type="text" maxlength="11" class="form-control" id="username" name="username" aria-describedby="emailHelp" placeholder="Enter Username">
    
  </div>
  <div class="form-group my-3">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" maxlength="23" class="form-control" id="password" name="password" placeholder="Password">
    <small id="emailHelp" class="form-text text-muted">Makesure to type same password and confirm password.</small>
  </div>
  <div class="form-group my-3">
    <label for="exampleInputPassword1">Confirm Password</label>
    <input type="password" class="form-control" id="confirmpassword" name="confirmpassword" placeholder="Password">
  </div>
  <button type="submit" class="btn btn-primary">SignUp</button>
</form>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>